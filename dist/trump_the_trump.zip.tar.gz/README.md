This extension will replace the word Trump and some varients with other words 
so you don't have to stomach any more of him than you have to.

Credits: 
- Kelby Carr & friend for idea!
- Frankicide for execution.

This is Open Source Software and the source code is located at:

     https://github.com/fmerenda/trump_the_trump
